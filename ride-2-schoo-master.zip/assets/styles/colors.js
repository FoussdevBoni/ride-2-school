export const colors = {
  primary: '#3498db',
  backgroundColor: '#ECF0F1'
}