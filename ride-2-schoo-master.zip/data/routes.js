
 
export const items = [
  {
    icon:'home',
    name:'Accueil',
    route: 'Ride 2 School',
    headerShow: false
},
{
    icon:'location',
    name:'R2S',
    route: 'Suivre mes Enfants',
    headerShow: false
},
{
    icon:'people',
    name:'Mes enfants',
    route: 'Mesenfants',
    headerShow: false
},
{
    icon:'bookmarks',
    name:'Mon contrat',
    route: 'Mon contrat',
    headerShow: false
},
{
    icon:'menu',
    name:'Plus',
    route: 'Menu',
    headerShow: false
},
]