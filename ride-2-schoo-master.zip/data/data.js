
export const appData = {
  logo: require('../assets/images/logo.png')
}