
const URL = "https://r2sbackend-1.onrender.com"

export const singIn = `${URL}/parent/login`
export const updateUser = `${URL}/parent/update`
export const createParent = `${URL}/parent/create`
export const getAdmins =  `${URL}/admin/allAdmin`

export const getSchools = `${URL}/ecole/getSchools`

export const addChild= `${URL}/parent/addChild/`
export const getChildren =  `${URL}/enfant/getEnfantParent`

